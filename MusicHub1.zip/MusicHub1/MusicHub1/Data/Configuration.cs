﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicHub1.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-BRJ6BRQ;Database=MusicHub1;Trusted_Connection=True;";
    }
}
